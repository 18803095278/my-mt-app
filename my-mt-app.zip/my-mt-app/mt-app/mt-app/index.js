console.log('哈喽')
console.log('邓哥')
console.log('111')
console.log('ok')
console.log('新增的')
console.log('dev分支上改的');
var a = 10;
<<<<<<< HEAD
var b = 10;
console.log(a + b);
=======
var c = 10;
console.log(a + c)
>>>>>>> dev
